# Operation Lumina Launch Guide

## FASTEST METHOD: GitHub Pages (5-10 minutes)

### Step 1: Create GitHub Account
1. Go to github.com
2. Sign up for free account (if you don't have one)

### Step 2: Create Repository
1. Click "New Repository" (green button)
2. Name it: `operation-lumina`
3. Check "Public"
4. Check "Add README"
5. Click "Create Repository"

### Step 3: Upload Your Files
1. Click "Add file" → "Upload files"
2. Drag and drop BOTH HTML files:
   - magic-by-design.html
   - operation-lumina-app.html
3. Rename magic-by-design.html to `index.html` (this makes it your homepage)
4. Click "Commit changes"

### Step 4: Enable GitHub Pages
1. Go to Settings (top right)
2. Click "Pages" (left sidebar)
3. Under "Source" select "main" branch
4. Click "Save"
5. Wait 2-3 minutes

### Step 5: Your Site is LIVE!
Your URL will be: `https://[your-username].github.io/operation-lumina`

Example: If your username is "coryncoco", your site is:
`https://coryncoco.github.io/operation-lumina`

---

## OPTION 2: Netlify Drop (Also Free, Even Easier)

### Step 1: Go to Netlify
1. Visit: https://app.netlify.com/drop
2. No account needed!

### Step 2: Drag & Drop
1. Create a folder on your computer called "operation-lumina"
2. Put both HTML files in it
3. Rename magic-by-design.html to index.html
4. Drag the ENTIRE FOLDER onto the Netlify Drop page

### Step 3: DONE!
- Site is live instantly
- You get a random URL like: `https://magical-phoenix-123abc.netlify.app`
- You can claim it and get a custom subdomain

---

## OPTION 3: Your Own Domain (cocynd.com)

### If you already have hosting:
1. Upload both files via FTP/cPanel File Manager
2. Create a subfolder: `/operation-lumina/`
3. Upload files there
4. Access at: `https://cocynd.com/operation-lumina/`

### If you need to buy hosting:
**Quick Recommendations:**
- **Netlify** (Free, connect custom domain)
- **Vercel** (Free, great for web apps)
- **Bluehost** ($2.95/mo, includes domain)

---

## BEFORE YOU LAUNCH CHECKLIST

### Update Video URL
In magic-by-design.html, find line ~254:
```html
src="https://www.youtube.com/embed/YOUR_VIDEO_ID"
```

Replace with your actual YouTube video:
1. Go to your YouTube video
2. Click "Share" → "Embed"
3. Copy the URL from `src="..."`
4. Paste it in the file

Example:
```html
src="https://www.youtube.com/embed/dQw4w9WgXcQ"
```

### Test Locally First
1. Double-click magic-by-design.html (opens in browser)
2. Click "Launch App" button
3. Test the app: add agent name, complete missions
4. Make sure everything works!

---

## CUSTOM DOMAIN SETUP (After Launch)

### Connect cocynd.com to GitHub Pages:
1. In your repository Settings → Pages
2. Add custom domain: `operationlumina.cocynd.com`
3. In your domain registrar (GoDaddy/Namecheap):
   - Add CNAME record
   - Name: `operationlumina`
   - Value: `[username].github.io`

### Or use main domain:
- Point `www.cocynd.com` to your GitHub Pages
- Or create `magicbydesign.com` subdomain

---

## SOCIAL MEDIA LAUNCH PLAN

### Monday Morning (8 AM):
**Post 1: The Reveal**
"🎄✨ OPERATION LUMINA IS LIVE ✨🎄

We've been working on something magical... 

Introducing a revolutionary way to empower children through the holidays and beyond.

No more naughty lists. No more surveillance.
Just growth, celebration, and transformation.

Meet Aurora Frost 👇
[LINK TO SITE]

#OperationLumina #MagicByDesign #ParentingRevolution"

### Monday Afternoon (2 PM):
**Post 2: Founding Agents**
"Want to be part of history?

The first families to join Operation Lumina become FOUNDING AGENTS 🌟

Limited spots. Special pricing. Lifetime benefits.

Presale ends [DATE]

Secure your spot: [LINK]

#FoundingAgent #OperationLumina"

### Monday Evening (6 PM):
**Post 3: The Story**
"Why we created Operation Lumina...

[Share your founder's story - the WHY]
[Link to website]"

---

## QUICK WINS FOR LAUNCH DAY

1. **Email your list** (if you have one)
2. **Post in parenting Facebook groups** (ask admins first)
3. **Share in your personal network**
4. **Tag relevant parenting influencers**
5. **Use hashtags:** #OperationLumina #ParentingTransformation #ChristmasMagic #EmpoweredKids

---

## TRACKING SUCCESS

### Add Google Analytics (Optional):
1. Get free Google Analytics code
2. Add before `</head>` in both HTML files
3. Track visitors, clicks, conversions

### Simple Tracking:
- GitHub shows visitor stats in Insights
- Netlify shows analytics in dashboard

---

## MONDAY TIMELINE

**Sunday Night (Tonight):**
- [ ] Choose launch method (GitHub Pages recommended)
- [ ] Upload files
- [ ] Update video URL
- [ ] Test everything
- [ ] Write social media posts
- [ ] Schedule posts (Buffer/Hootsuite)

**Monday 7 AM:**
- [ ] Final check - site is live
- [ ] Test on mobile
- [ ] Test app functionality

**Monday 8 AM:**
- [ ] Press PUBLISH on social posts
- [ ] Send emails
- [ ] Go live!

**Monday 9 AM - 5 PM:**
- [ ] Respond to comments
- [ ] Share in groups
- [ ] Engage with audience

---

## TROUBLESHOOTING

**Site won't load?**
- GitHub Pages: Wait 5 minutes, clear cache
- Check repository is public
- Verify index.html is named correctly

**App not working?**
- Check browser console (F12)
- Make sure JavaScript is enabled
- Test in Chrome/Firefox

**Video not showing?**
- Verify YouTube URL is correct
- Check video is public, not private
- Try embed code directly from YouTube

---

## NEED HELP?

**Free Resources:**
- GitHub Pages Docs: https://pages.github.com
- Netlify Docs: https://docs.netlify.com
- YouTube embedding: https://support.google.com/youtube/answer/171780

**Quick Support:**
- GitHub Community Forum
- Netlify Support Chat
- Stack Overflow

---

## YOU'VE GOT THIS! 🚀

Your Operation Lumina launch is going to be AMAZING.

Remember: Done is better than perfect.
Launch Monday. Iterate Tuesday.

The magic is in the mission, not the polish.

Let's change how families celebrate growth! ✨
