# Stripe Product Setup - Copy/Paste Ready

## Product Name:
```
Operation Lumina - Founding Agent Kit with Limited Edition Aurora Frost Doll (ONLY 50)
```

## Product Description:
```
🌟 LIMITED EDITION FOUNDING AGENT KIT 🌟
Only 50 Will Ever Be Made

OWN A PIECE OF MAGIC - This collector's edition includes the EXCLUSIVE Aurora Frost doll that will NEVER be released again. After these 50 kits sell, future versions will not include this limited edition doll.

✨ WHAT'S INCLUDED ✨

LIMITED EDITION AURORA FROST DOLL:
🎁 11" collectible fashion doll with exclusive details
🎁 Gold foil accents on uniform (Founding Agent exclusive only)
🎁 Premium display stand engraved with your agent number
🎁 Character story card
🎁 This exact doll will NEVER be available again

COMPLETE FIELD KIT:
⭐ Magnetic Star Tracker (interactive display piece)
⭐ 30 Mission Cards - Starter deck (expandable)
⭐ 25 Gold Star Magnets for progress tracking
⭐ Field Agent Badge (clip-on credential)
⭐ Founding Agent Certificate - Hand-numbered 1-50
⭐ Digital App Access (iOS & Android) - Immediate download
⭐ Parent Transmission Guide
⭐ Premium magnetic-closure gift box

EXCLUSIVE FOUNDING AGENT BENEFITS:
✅ Only 50 numbered certificates will ever exist
✅ Lifetime access to all app updates and new features
✅ First access to new characters (Wrangler Jack coming soon!)
✅ Private Founding Agents community
✅ Your name in our Hall of Fame forever
✅ Legacy pricing - Save $50 off regular price

💎 TRUE COLLECTIBLE VALUE 💎
Regular Operation Lumina kits (after these 50 sell): $97 WITHOUT exclusive doll
Standalone Aurora doll (if ever released): $67 WITHOUT exclusive details
Complete kit with exclusive doll after Founding Agents: $197

YOUR FOUNDING AGENT PRICE: $147
YOU SAVE: $50 + Own exclusive collectible that increases in value

🎄 WHAT IS OPERATION LUMINA? 🎄

A revolutionary children's empowerment program created by Aurora Frost, Head of North Pole Security. No more naughty lists - just growth, celebration, and transformation.

HELPS CHILDREN DEVELOP:
• Responsibility & Self-Management
• Emotional Intelligence
• Problem-Solving Skills
• Growth Mindset
• Integrity & Honesty
• Empathy & Kindness

Perfect for ages 5-12. Screen time balanced with tactile play. COPPA compliant and privacy-first.

⚡ SHIPS JANUARY 2026 ⚡
FREE SHIPPING on all Founding Agent orders

Digital app access is immediate upon purchase.
Physical kit ships January 2026.

ABOUT THE DOLL:
Aurora Frost is a water elf who transformed the North Pole's approach from surveillance to empowerment. She learned from a child that "you're not judging the action, you're judging the intent" - and created Operation Lumina to celebrate children's growth.

This limited edition doll captures her in her most exclusive form, available ONLY to the first 50 Founding Agents.

⚠️ ONCE THESE 50 SELL, THIS EXACT KIT WILL NEVER BE AVAILABLE AGAIN ⚠️

Secure your numbered kit today and become part of history!

From Magic By Design (CocynD LLC)
Visit: magicbydesign.com
Questions: support@magicbydesign.com
```

## Price:
```
$147.00 USD
```

## Quantity Limit:
```
50
```
(Set this in Stripe so it automatically stops at 50 sales)

---

# STRIPE SETUP STEPS

## 1. Create Stripe Account
- Go to: stripe.com
- Click "Start now"
- Sign up with email
- Complete business verification

## 2. Create Payment Link
1. Log into Stripe Dashboard
2. Click "Payment Links" in left sidebar
3. Click "New" or "+ Create payment link"

## 3. Enter Product Details
- **Name**: Copy from above
- **Description**: Copy from above  
- **Price**: $97.00
- **Currency**: USD

## 4. Set Quantity Limit
- Scroll to "Advanced settings"
- Toggle "Limit quantity"
- Set to: 50
- This makes Stripe automatically disable link at 50 sales!

## 5. Configure Settings
- **Collect customer information**: YES
  - Name
  - Email
  - Phone (optional)
  - Shipping address (YES - you need this for Field Kits!)

- **After payment**: Redirect to page
  - URL: Your website thank you page (or back to main site)
  - Message: "Thank you! Check your email for next steps."

## 6. Success Message Email
Stripe auto-sends receipt. Add custom text:

```
🎄 WELCOME, FOUNDING AGENT! 🎄

Congratulations on becoming one of the first 50 families to join Operation Lumina!

NEXT STEPS:

1. ACCESS YOUR DIGITAL CONTENT:
   → Download your app at: [your-website-url]/operation-lumina-app.html
   → Watch Aurora's welcome video: [YouTube link]
   → Download your Parent Guide: [link to PDF]

2. CONFIRM YOUR SHIPPING ADDRESS:
   We'll ship your Physical Field Kit in January 2026.
   Please confirm your address here: [Google Form link]

3. JOIN THE COMMUNITY:
   Founding Agents Facebook Group: [Facebook group link]

Your Founding Agent Number: #[will be assigned]
Your numbered certificate will arrive with your Field Kit!

Questions? Just reply to this email!

Welcome to the revolution,
Coryn & Cynarra
Magic By Design

P.S. Share Operation Lumina with friends! The more families we empower, the better. ✨
```

## 7. Get Your Payment Link
- Click "Create link"
- Copy the URL (looks like: https://buy.stripe.com/abc123xyz)
- This is what you paste into your website!

---

# WHAT TO DO WITH YOUR STRIPE LINK

## Update Your Website:

1. Open `index.html`
2. Find this line (around line 420):
   ```html
   <a href="https://buy.stripe.com/YOUR_STRIPE_LINK_HERE" class="cta-button" id="foundingAgentBtn">
   ```

3. Replace `YOUR_STRIPE_LINK_HERE` with your actual Stripe link:
   ```html
   <a href="https://buy.stripe.com/abc123xyz" class="cta-button" id="foundingAgentBtn">
   ```

4. Save and upload to GitHub

5. DONE! Your buy button is live! 🎉

---

# AFTER YOUR FIRST SALE

## You'll receive:
1. Email notification from Stripe
2. Money in your Stripe balance (available in 2-7 days)
3. Customer details in Stripe Dashboard

## What to do:
1. Check Stripe Dashboard for customer info
2. Send personalized welcome email (optional - Stripe already sent receipt)
3. Add to your tracking spreadsheet
4. Update website spot counter (change SPOTS_SOLD from 0 to 1)
5. Celebrate! 🎉

---

# STRIPE FEES

Stripe charges per transaction:
- **2.9% + $0.30** per successful payment

For $97 sale:
- Stripe fee: $3.11
- You receive: $93.89

The money appears in your Stripe balance and transfers to your bank automatically (default: every 2 days).

---

# TESTING BEFORE LAUNCH

1. In Stripe Dashboard, toggle "Test mode" (top right)
2. Create a test payment link
3. Use test credit card: 4242 4242 4242 4242
4. Verify email sends correctly
5. Check everything works
6. Toggle back to "Live mode" for real launch!

---

# TROUBLESHOOTING

**"Payment link not working"**
- Make sure you're in Live mode, not Test mode
- Check link copied correctly
- Verify your Stripe account is fully activated

**"Customer didn't get email"**
- Check their spam folder
- Verify email in Stripe Dashboard shows "sent"
- You can manually resend from Dashboard

**"How do I refund?"**
- Go to Stripe Dashboard → Payments
- Find the payment
- Click "Refund" 
- Stripe handles it automatically

---

# PRO TIP: Google Form for Shipping

Create a simple Google Form to collect shipping info:

**Form Title:** "Founding Agent Shipping Information"

**Questions:**
1. Full Name
2. Email (to match Stripe purchase)
3. Shipping Address
4. City
5. State/Province
6. ZIP/Postal Code
7. Country
8. Phone Number
9. Any special delivery instructions?

**Share link in your Stripe success email!**

This way you collect verified shipping addresses and can fulfill in January.

---

You're ready to launch! 🚀
