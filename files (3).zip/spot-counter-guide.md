# How to Update Your Founding Agent Spot Counter

## Every Time You Make a Sale:

### OPTION 1: Simple Manual Update (5 minutes)

1. **Open `index.html` in a text editor** (Notepad, TextEdit, VS Code)

2. **Scroll to the bottom** (around line 450)

3. **Find this line:**
   ```javascript
   const SPOTS_SOLD = 0; // UPDATE THIS NUMBER AS YOU SELL!
   ```

4. **Change the number:**
   - First sale: `const SPOTS_SOLD = 1;`
   - Second sale: `const SPOTS_SOLD = 2;`
   - Third sale: `const SPOTS_SOLD = 3;`
   - etc.

5. **Save the file**

6. **Re-upload to GitHub:**
   - Go to your repository
   - Click on `index.html`
   - Click the pencil icon (edit)
   - Delete old content
   - Paste updated content
   - Scroll down and click "Commit changes"

7. **Wait 1-2 minutes** - Your site will update automatically!

---

## What Updates Automatically:

When you change `SPOTS_SOLD`, the website automatically updates:

- ✅ "50 Spots Remaining" → Changes to 49, 48, 47, etc.
- ✅ "0 Claimed" → Changes to 1, 2, 3, etc.
- ✅ "Become Founding Agent #1" → Changes to #2, #3, #4, etc.
- ✅ When you hit 50 sold → Site shows "SOLD OUT" message automatically

---

## Example Updates:

### After 1st Sale:
```javascript
const SPOTS_SOLD = 1;
```
Website shows: "1 Claimed • 49 Remaining" and "Become Founding Agent #2"

### After 10th Sale:
```javascript
const SPOTS_SOLD = 10;
```
Website shows: "10 Claimed • 40 Remaining" and "Become Founding Agent #11"

### After 25th Sale:
```javascript
const SPOTS_SOLD = 25;
```
Website shows: "25 Claimed • 25 Remaining" and "Become Founding Agent #26"

### After 50th Sale (SOLD OUT):
```javascript
const SPOTS_SOLD = 50;
```
Website automatically hides the buy button and shows:
"🎉✨🌟 FOUNDING AGENTS: SOLD OUT!"

---

## OPTION 2: Use Stripe Webhook (Advanced - Set Up Later)

If you want automatic updates without manual editing:

1. Set up a simple database (Google Sheets or Airtable)
2. Connect Stripe webhook to update sheet on purchase
3. Have website read from sheet
4. 100% automatic!

(Set this up after launch if you want - manual is fine for now!)

---

## Pro Tips:

### Daily Update Schedule:
- **Morning (9 AM)**: Check Stripe dashboard, update counter
- **Afternoon (3 PM)**: Check again, update if new sales
- **Evening (8 PM)**: Final check, post social update with spots remaining

### Social Media Updates:
Every 5-10 sales, post an update:

**Example Post:**
"🚨 UPDATE: 15 FOUNDING AGENT SPOTS CLAIMED! 🚨

Only 35 spots remaining!

Don't miss your chance to be one of the first 50 families to join Operation Lumina.

Secure your spot: [LINK]

#FoundingAgent #OperationLumina"

---

## Tracking Spreadsheet (Recommended):

Keep a simple spreadsheet to track:

| Agent # | Name | Email | Purchase Date | Stripe ID | Shipped? |
|---------|------|-------|---------------|-----------|----------|
| 1 | Sarah M | sarah@email.com | 12/16/24 | ch_abc123 | No |
| 2 | Mike J | mike@email.com | 12/16/24 | ch_def456 | No |
| 3 | ... | ... | ... | ... | ... |

This helps you:
- Update the counter accurately
- Know who to ship to
- Send personalized welcome emails
- Award correct agent numbers

---

## Need Help?

If you're not comfortable editing HTML:
1. Send me a message with "I made X sales"
2. I'll give you the exact updated code
3. You just copy/paste into GitHub

You've got this! 🚀
