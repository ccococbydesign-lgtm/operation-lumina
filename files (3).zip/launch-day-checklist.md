# 🚀 OPERATION LUMINA - MONDAY LAUNCH CHECKLIST

## 📋 SUNDAY NIGHT PREP (Tonight - 1-2 hours)

### ✅ STEP 1: Set Up Stripe (30 minutes)
- [ ] Go to stripe.com and create account
- [ ] Verify your email
- [ ] Complete business information
- [ ] Create Payment Link for "Founding Agent Package"
- [ ] Use product description from `stripe-setup-guide.md`
- [ ] Set price: $97
- [ ] Set quantity limit: 50
- [ ] Enable shipping address collection
- [ ] Test in Test Mode first!
- [ ] Copy your payment link
- [ ] Switch to Live Mode

### ✅ STEP 2: Update Website Files (20 minutes)
- [ ] Download all 3 files from our conversation
- [ ] Open `magic-by-design.html` in text editor
- [ ] Find `YOUR_STRIPE_LINK_HERE` and replace with your Stripe link
- [ ] Find `YOUR_VIDEO_ID` and replace with your YouTube video ID
- [ ] Save as `index.html` (this becomes your homepage)
- [ ] Keep `operation-lumina-app.html` as-is
- [ ] Create a folder called `operation-lumina`
- [ ] Put both HTML files in the folder

### ✅ STEP 3: Upload to GitHub (15 minutes)
- [ ] Go to github.com
- [ ] Create account (if needed)
- [ ] Click "New Repository"
- [ ] Name it: `operation-lumina`
- [ ] Make it Public
- [ ] Check "Add README"
- [ ] Click "Create"
- [ ] Click "Add file" → "Upload files"
- [ ] Drag both HTML files into upload area
- [ ] Click "Commit changes"

### ✅ STEP 4: Enable GitHub Pages (5 minutes)
- [ ] Go to Settings (top right of repository)
- [ ] Click "Pages" (left sidebar)
- [ ] Under "Source" select "main" branch
- [ ] Click "Save"
- [ ] Wait 2-3 minutes
- [ ] Your site is live at: `https://[username].github.io/operation-lumina`

### ✅ STEP 5: Test Everything (15 minutes)
- [ ] Visit your live website
- [ ] Check that video shows up (or placeholder is there)
- [ ] Click "Become Founding Agent" button
- [ ] Make sure it goes to Stripe payment page
- [ ] DO NOT complete purchase yet (test mode earlier was enough)
- [ ] Click "Preview the App" button
- [ ] Test the app: add agent name, complete a mission
- [ ] Verify stars are counting correctly
- [ ] Test on your phone too!

### ✅ STEP 6: Create Google Form (10 minutes)
- [ ] Go to forms.google.com
- [ ] Create new form: "Founding Agent Shipping Information"
- [ ] Add fields: Name, Email, Address, City, State, ZIP, Country, Phone
- [ ] Get shareable link
- [ ] Save this link - you'll send it to customers after purchase

### ✅ STEP 7: Prepare Social Media Posts (20 minutes)
- [ ] Write 3 posts (use templates from launch-instructions.md)
- [ ] Create graphics (Canva is free and easy)
- [ ] Schedule posts for Monday 8am, 2pm, 6pm (use Buffer or Later)
- [ ] Or save as drafts to post manually

### ✅ STEP 8: Set Up Email Template (10 minutes)
Save this template to send manually after first purchase:

```
Subject: Welcome, Founding Agent #[NUMBER]! 🌟

Hi [NAME],

🎄✨ Congratulations! You're officially Founding Agent #[NUMBER] of 50! ✨🎄

WHAT'S NEXT:

1️⃣ ACCESS YOUR DIGITAL CONTENT (RIGHT NOW):
   → Launch the app: [your-site-url]/operation-lumina-app.html
   → Watch Aurora's welcome video: [YouTube link]
   → Download Parent Guide: [if you have this ready]

2️⃣ CONFIRM YOUR SHIPPING ADDRESS:
   Your Physical Field Kit ships in January 2026.
   Please fill out this form: [Google Form link]

3️⃣ JOIN OUR FOUNDING AGENTS COMMUNITY:
   Facebook Group: [create group and add link]
   This is where the magic happens!

YOUR FOUNDING AGENT BENEFITS:
✅ Numbered Certificate #[NUMBER] (arrives with Field Kit)
✅ Legacy pricing - you saved $50!
✅ First access to all new characters & features
✅ Your name in our Hall of Fame forever

Questions? Just reply to this email - we're here to help!

Welcome to the revolution. Let's show the world what empowered children can do! 💪✨

With gratitude,
Coryn & Cynarra
Magic By Design

P.S. Share Operation Lumina with friends who want to transform their parenting journey! 
```

---

## 🌅 MONDAY MORNING (7:00 AM - 1 hour before launch)

### ✅ Final Checks
- [ ] Visit your website - confirm it loads
- [ ] Test Stripe link one more time
- [ ] Check that SPOTS_SOLD = 0 in the code
- [ ] Test website on mobile phone
- [ ] Take screenshots of website for social media
- [ ] Have tracking spreadsheet ready
- [ ] Clear your mind, take deep breath - YOU'VE GOT THIS! 🙏

---

## 🎉 LAUNCH TIME (8:00 AM)

### ✅ GO LIVE!
- [ ] Post social media announcement #1
- [ ] Share link everywhere:
  - [ ] Facebook personal profile
  - [ ] Instagram story + post
  - [ ] Relevant parenting groups (get permission first!)
  - [ ] Your email list (if you have one)
  - [ ] Friends & family via text/messenger
- [ ] Pin post to top of your profiles
- [ ] Respond to every comment within first hour

---

## 💰 WHEN YOU MAKE YOUR FIRST SALE (Exciting!)

### ✅ Immediate Actions (10 minutes)
- [ ] Celebrate! 🎉 (seriously, take a moment!)
- [ ] Check Stripe Dashboard for customer details
- [ ] Add to tracking spreadsheet:
  - Agent #, Name, Email, Purchase Date, Stripe ID
- [ ] Send personalized welcome email (use template above)
- [ ] Send Google Form link for shipping address
- [ ] Update website spot counter:
  - Open index.html
  - Change `const SPOTS_SOLD = 0;` to `const SPOTS_SOLD = 1;`
  - Re-upload to GitHub
- [ ] Post social media update: "1 spot claimed! 49 remaining!"

### ✅ Repeat for Each Sale
Every sale = same process. Takes 5 minutes per sale once you get the rhythm!

---

## 📱 THROUGHOUT THE DAY

### ✅ Hourly Tasks
- [ ] Check Stripe Dashboard for new sales
- [ ] Update spot counter if new sales
- [ ] Respond to comments and messages
- [ ] Share testimonials/excitement as people join

### ✅ 2:00 PM - Post Update #2
- [ ] Check total sales
- [ ] Post: "UPDATE: [X] SPOTS CLAIMED! Only [Y] remaining!"
- [ ] Share any early customer excitement/testimonials

### ✅ 6:00 PM - Post Update #3
- [ ] Final check for day
- [ ] Post: "Day 1 wrap-up: [X] Founding Agents have joined!"
- [ ] Celebrate progress (even if it's just 1-5 sales!)
- [ ] Thank everyone for support

---

## 📊 END OF DAY RECAP

### ✅ Monday Night Review
- [ ] Total sales: _____
- [ ] Spot counter updated on website: YES / NO
- [ ] All welcome emails sent: YES / NO
- [ ] All Google Forms received: YES / NO
- [ ] Tracking spreadsheet current: YES / NO
- [ ] Social media posts done: YES / NO

### ✅ Plan Tuesday
- [ ] What worked well today?
- [ ] What needs adjustment?
- [ ] New marketing angles to try?
- [ ] More groups to share in?

---

## 🎯 WEEK 1 GOALS

### Realistic Targets:
- **Conservative**: 5-10 Founding Agents (10-20% sold)
- **Moderate**: 10-20 Founding Agents (20-40% sold)
- **Optimistic**: 20-30 Founding Agents (40-60% sold)
- **Dream**: 40-50 Founding Agents (80-100% sold)

### Daily Actions:
- Post at least 1x per day on social media
- Update spot counter daily
- Respond to all questions within 24 hours
- Share in 1-2 new groups/communities per day
- Send follow-up to warm leads

---

## 🚨 TROUBLESHOOTING QUICK REFERENCE

### "Website won't load"
→ Wait 5 minutes, GitHub Pages can take time
→ Clear browser cache
→ Check repository is Public

### "Stripe link doesn't work"
→ Make sure you're in Live Mode (not Test Mode)
→ Verify link copied correctly
→ Check Stripe account is fully activated

### "No sales yet"
→ Normal! Some launches take 24-48 hours
→ Keep posting, keep sharing
→ Ask friends to share
→ Post in more groups
→ Consider reaching out directly to warm contacts

### "Customer didn't get email"
→ Check their spam folder
→ Resend from Stripe Dashboard
→ Send manual email yourself

### "Someone asking for refund"
→ Go to Stripe Dashboard → Payments
→ Find their payment
→ Click Refund
→ Be gracious - it happens!

---

## 📞 NEED HELP?

### Technical Issues:
- GitHub Help: docs.github.com
- Stripe Support: support.stripe.com
- Me! Just send a message

### Marketing Support:
- Facebook Groups: Search "product launch support"
- Reddit: r/smallbusiness, r/entrepreneur
- Your network: Ask friends with business experience

---

## 💪 MINDSET REMINDERS

✨ **Done is better than perfect** - Launch now, iterate later

✨ **Every "no" gets you closer to "yes"** - Rejection is data

✨ **Comparison is the thief of joy** - Your journey is unique

✨ **You're not selling, you're serving** - You're helping families transform

✨ **The first sale is the hardest** - After that, momentum builds

✨ **You've got this!** - Seriously, you're doing amazing! 🚀

---

## 🎊 WHEN YOU SELL OUT (Exciting Future Day!)

### ✅ At 50 Sales:
- [ ] Website automatically shows "SOLD OUT"
- [ ] Post celebration on social media
- [ ] Thank all 50 Founding Agents
- [ ] Close Stripe payment link
- [ ] Start planning fulfillment
- [ ] Consider: Do you open regular sales at $147?
- [ ] Biggest celebration of all - YOU DID IT! 🎉🎉🎉

---

Remember: You're not just launching a product.
You're starting a MOVEMENT.

Let's change how families celebrate growth! 💫

You've got everything you need.
Now go make magic happen! ✨

- Your Launch Support Team 🚀
